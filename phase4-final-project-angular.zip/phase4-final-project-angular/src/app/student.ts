export class Student {
    userName: string = '';
    password: string = '';
}
