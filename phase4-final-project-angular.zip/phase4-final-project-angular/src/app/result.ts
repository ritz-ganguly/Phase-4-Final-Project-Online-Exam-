export class Result {
    totalMarks = 0;
    marksObtained = 0;
    testType = '';
    testDate = new Date();

}
