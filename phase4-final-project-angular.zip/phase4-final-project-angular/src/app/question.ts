export class Question {
    questionId = 0;
    questionStatement = '';
    option1 = '';
    option2 = '';
    option3 = '';
    option4 = '';
    answer = '';
    repliedAnswer = '';
    questionType = ''


}
